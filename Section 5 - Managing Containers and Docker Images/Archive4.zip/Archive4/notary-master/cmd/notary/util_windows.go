package main

const homeEnv = "USERPROFILE"
