## Credits

This implementation was originally forked from [flynn/go-tuf](https://github.com/flynn/go-tuf)

This implementation retains the same 3 Clause BSD license present on 
the original flynn implementation.
